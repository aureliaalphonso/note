package com.example.note.activites;

import javax.xml.transform.Result;

public interface SaveNoteTask {
    void onPostExecute(Result aVoid);
}
